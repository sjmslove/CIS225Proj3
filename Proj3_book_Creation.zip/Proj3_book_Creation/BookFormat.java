
/**
 * Write a description of class BookFormat here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BookFormat
{
    // instance variables - replace the example below with your own
    private String LastName;
    private String FirstName;
    private int IsbnNumber;
    private String BookTitle;
    private int PublicationDate;
    private int PageNumber;
    
    /**
     * Constructor for objects of class BookFormat
     */
    public BookFormat(String LastName, String FirstName, int IsbnNumber, String BookTitle, int PublicationDate, int PageNumber)
    {
        this.LastName = LastName;
        this.FirstName = FirstName;
        this.IsbnNumber = IsbnNumber;
        this.BookTitle = BookTitle;
        this.PublicationDate = PublicationDate;
        this.PageNumber = PageNumber;
    }

    /**
     * set LastName
     */
    public void setLastName(String Name)
    {
       this.LastName = Name;
    }
    
     /**
     * get LastName
     */
    public String getLastName()
    {
        return LastName;
    }
    
    /**
     * set FirstName
     */
    public void setFirstName(String Name)
    {
       this.FirstName = Name;
    }
    
    /**
     * get FirstName
     */
    public String getFirstName()
    {
        return FirstName;
    }
    
    /**
     * set ISBN
     */
    public void setISBN(int Number)
    {
       this.IsbnNumber = Number;
    }
    
    /**
     * get ISBN
     */
    public int getISBN()
    {
        return IsbnNumber;
    }
     /**
     * set BookTitle
     */
    public void setBookTitle(String Name)
    {
       this.BookTitle = Name;
    }
    
    /**
     * get BookTitle
     */
    public String getBookTitle()
    {
        return BookTitle;
    }
    
    /**
     * set PublicationDate
     */
    public void setPublicationDate(int Number)
    {
       this.PublicationDate = Number;
    }
    
    /**
     * get PublicationDate
     */
    public int getPublicationDate()
    {
        return PublicationDate;
    }
    
     /**
     * set PageNumber
     */
    public void setPageNumber(int Number)
    {
       this.PageNumber = Number;
    }
    
    /**
     * get PageNumber
     */
    public int getPageNumber()
    {
        return PageNumber;
    }
}
