
/**
 * Write a description of class CreateNewBook here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CreateNewBook
{
   
    BookFormat book;
    /**
     * Constructor for objects of class CreateNewBook
     */
    public CreateNewBook()
    {
        
    }

 
    public void CreateaNewBook(String LastName, String FirstName, int IsbnNumber, String BookTitle, int PublicationDate, int PageNumber)
    {
        book = new BookFormat(LastName, FirstName, IsbnNumber, BookTitle, PublicationDate, PageNumber);
        System.out.println( "Last Name: " + book.getLastName());
        System.out.println( "First Name: " + book.getFirstName());
        System.out.println( "ISBN Number: " + book.getISBN());
        System.out.println( "Book Title: " + book.getBookTitle());
        System.out.println( "PublicationDate: " + book.getPublicationDate());
        System.out.println( "Page Number: " + book.getPageNumber());
    }
    
}
